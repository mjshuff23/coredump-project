**Templates**

- navigation.pug [search bar, sign up/sign in buttons, questions]
- signup.pug
- login.pug
- index.pug [banner page]
- site-layout.pug
- signup.pug
- questions-ask.pug
- questions-answer.pug
- questions-list.pug

**
Index.pug [banner page]

signup.pug
login.pug


**
