![workflow](https://github.com/mjshuff23/coredump-project/blob/main/documentation/feature-packets/coredumpworkflow.png?raw=true)
