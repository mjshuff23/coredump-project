**Core Dump** is a website for users to ask their coding questions and get their questions answered. You will be able to create a user account, ask questions, answer questions, and upvote and downvote questions.

**Overseer** - Mary
**Project Manager** - Michael
**Models Manager** - John
**UX Manager** - Ronald

**Core Dump Features**

- Ask Questions
- Answer Questions
- Search for Questions/Answers
- Upvote/Downvote Questions
- Determine which question/answer has most votes to pass to UI for green checkmark
